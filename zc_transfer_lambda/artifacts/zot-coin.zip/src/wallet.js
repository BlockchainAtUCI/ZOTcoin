"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const nem_library_1 = require("nem-library");
const config_1 = require("../config/config");
const Observable_1 = require("rxjs/Observable");
nem_library_1.NEMLibrary.bootstrap(nem_library_1.NetworkTypes.TEST_NET);
class AutoZCSender {
    constructor() {
        this.account = nem_library_1.Account.createWithPrivateKey(config_1.config.PRIVATE_KEY);
    }
    sendZCTo(addr, qty, callback) {
        const transactionHttp = new nem_library_1.TransactionHttp();
        const mosaicHttp = new nem_library_1.MosaicHttp();
        return new Promise((resolve) => {
            Observable_1.Observable.from([
                { mosaic: new nem_library_1.MosaicId(config_1.config.ZC_MOSAIC.namespace, config_1.config.ZC_MOSAIC.mosaic_name), quantity: qty },
            ]).flatMap(_ => mosaicHttp.getMosaicTransferableWithAmount(_.mosaic, _.quantity))
                .toArray()
                .map(mosaics => nem_library_1.TransferTransaction.createWithMosaics(nem_library_1.TimeWindow.createWithDeadline(), new nem_library_1.Address(addr), mosaics, nem_library_1.EmptyMessage))
                .map(transaction => this.account.signTransaction(transaction))
                .flatMap(signedTransaction => transactionHttp.announceTransaction(signedTransaction))
                .subscribe(nemAnnounceResult => {
                resolve(nemAnnounceResult);
            });
        });
    }
    getAccountBalance() {
        return new Promise((resolve, reject) => {
            const accountHttp = new nem_library_1.AccountHttp();
            accountHttp.getMosaicOwnedByAddress(this.account.address).subscribe(mosaics => {
                resolve(mosaics);
            }, err => {
                reject(err);
            });
        });
    }
    mosaicBalance() {
        return __awaiter(this, void 0, void 0, function* () {
            const balances = yield this.getAccountBalance();
            const mFound = balances.find((mosaic) => {
                return mosaic.mosaicId.name === config_1.config.ZC_MOSAIC.mosaic_name;
            });
            if (!mFound)
                return 0;
            return mFound.quantity;
        });
    }
    xemBalance() {
        return __awaiter(this, void 0, void 0, function* () {
            const balances = yield this.getAccountBalance();
            const xemFound = balances.find((mosaic) => {
                return mosaic.mosaicId.name === 'xem';
            });
            if (!xemFound) {
                return 0;
            }
            return xemFound.quantity;
        });
    }
}
exports.AutoZCSender = AutoZCSender;
//# sourceMappingURL=wallet.js.map