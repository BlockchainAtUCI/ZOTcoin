'use strict';
Object.defineProperty(exports, "__esModule", { value: true });
const wallet_1 = require("./src/wallet");
const zc_send_trigger = (event, context, callback) => {
    const response = {
        statusCode: 200,
        body: JSON.stringify({})
    };
    var addr = event.address;
    var amount = event.amount;
    var autoSender = new wallet_1.AutoZCSender();
    autoSender.sendZCTo(addr, amount, callback).then((nemAnnounceResult) => {
        response.body = JSON.stringify(nemAnnounceResult);
        callback(undefined, response);
    });
};
exports.zc_send_trigger = zc_send_trigger;
//# sourceMappingURL=handler.js.map