"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = {
    ZC_MOSAIC: {
        namespace: "playground",
        mosaic_name: "pcoin",
        quantity: 1
    },
    PRIVATE_KEY: "d2c94d7da8696adef1ca3d8d639bcf54e09ced8654ad41fab4d233331b2540ca"
};
//# sourceMappingURL=config.js.map